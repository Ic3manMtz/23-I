<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Page Title</title>
</head>
<body>

<form action = "prueba.php" method = "post">
Introduzca el tamaño de la USB...... 
<input type = "text" name = "tamano">
<input type = "hidden" name = "forma_confirmada" value = "1" />
<input type = "submit" value = "Confirmar">

<?php

/*
Malinali Becerril
Mejia Mendoza
Martinez Buenrostro
*/


function obtenerDatos($lista,$tam){
    $suma = 0;
    $cuenta = 0;
    foreach($lista as $valor){
        $temp = $suma + $valor;
        if($temp <= $tam){
            $cuenta++;
            $suma += $valor;
        }
    }

    return $cuenta--;
}

function valorTotal($lista,$cuenta,$n){
    $i = 0;
    $suma = 0;
    $actual = current($lista);

    echo "<br/>";

    if(n == 1){
        foreach($lista as $valor => $mbyte){
            if($i < $cuenta){
                $suma += $valor;
                $i++;
            }
        }
        return $suma;
    }

    if(n == 2){
        foreach($lista as $valor => $mbyte){
            if($i < $cuenta){
                $suma += $mbyte;
                $i++;
            }
        }
        return $suma;
    }
    

}

function mostrarLista($lista,$cuenta){
    echo "<br/>";
    $i = 0;
    $valores = 0;
    $mbytes = 0;
    
    foreach($lista as $valor => $mbyte){
        if($i < $cuenta){
            echo "{$valor} => {$mbyte} <br/>";
            $valores += $valor;
            $mbytes += $mbyte;
            $i++;
        }
    }

    echo "Datos con valor $valores y capacidad $mbytes Mb";
}

$tam = $_POST['tamano'];
$f = fopen("datos.csv","r");
$lista;

while(!feof($f)){
    $linea = fgets($f,99);
    $elemento = strtok($linea,",");
    $valor = intval($elemento);
    
    while($elemento != null){
        $elemento = strtok(",");

        if($elemento != null){
            $mbyte = intval($elemento);
        }
    }
    $lista[$valor] = $mbyte;
}

fclose($f);
array_pop($lista);

$listaValores = $lista;
$listaMbytes = $lista;
ksort($listaValores);
asort($listaMbytes);

$cuenta_1 = obtenerDatos($listaValores,$tam);
$mbytes_1 = valorTotal($listaValores,$cuenta_1,1);


$cuenta_2 = obtenerDatos($listaMbytes,$tam);
$mbytes_2 = valorTotal($listaMbytes,$cuenta_2,1);

if( $suma_1 > $suma_2){
    mostrarLista($listaValores,$cuenta_1);
}else{
    mostrarLista($listaMbytes,$cuenta_2);
}



?>
</body>
</html>