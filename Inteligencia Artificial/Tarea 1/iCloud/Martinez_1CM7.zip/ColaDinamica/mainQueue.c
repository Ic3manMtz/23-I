//Gustavo Garcia Sanchez
//Martinez Buenrostro Jorge Lupito

#include <stdio.h>
#include "DynamicQueue.h"

main(){
	queue q;
	q = createQueue();
	require(q);
	display(q);

}